email = "samanalexhash@gmail.com"
password = "passwordss"
positions = ["Frontend Developer", "Software Developer", "Software Engineer", "Full Stack Software Engineer"]
avoid_words = ["Senior", "Junior"]
years_exp = 5
bonus_words = []
